<?php
// CHECK PAYMENT IS COMPLETE.

	function ksher_paramData( $data ) {
		ksort($data);
		$message = '';
		foreach ($data as $key => $value) {
				$message .= $key . "=" . $value;
		}
		$message = mb_convert_encoding($message, "UTF-8");
		return $message;
	}

	function ksher_verify_sign( $data, $sign ) {
		$pubkey = <<<EOD
-----BEGIN PUBLIC KEY-----
MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAL7955OCuN4I8eYNL/mixZWIXIgCvIVE
ivlxqdpiHPcOLdQ2RPSx/pORpsUu/E9wz0mYS2PY7hNc2mBgBOQT+wUCAwEAAQ==
-----END PUBLIC KEY-----
EOD;
		$sign = pack("H*",$sign);
		$message = ksher_paramData( $data );
		$res = openssl_get_publickey($pubkey);
		$result = openssl_verify($message, $sign, $res, OPENSSL_ALGO_MD5);
		openssl_free_key($res);
		return $result;
	}

	add_action('woocommerce_thankyou', 'ksher_check_payment_is_complete', 10, 1);
	function ksher_check_payment_is_complete( $order_id )
	{
		global $woocommerce;
		if ( isset($_GET['mch_order_no']) && $_GET['mch_order_no'] ) {
			$make_order = explode('-', $_GET['mch_order_no']); ;
			$order = wc_get_order( $make_order[0] );
			$status = $order->get_status();

			$timestamp = current_time('timestamp');
			$nonce_str = bin2hex(random_bytes(16));

			$data = array(
				'appid' =>  get_option('ksher_app_id'),
				'mch_order_no' =>  $_GET['mch_order_no'],
				'nonce_str' => $nonce_str,
				'time_stamp' => $timestamp,
			);

			$privatekey_content = file_get_contents( get_option('ksher_private_key_file') );
			$encoded_sign = sign_process( $privatekey_content, $data); 
			$data['sign'] = $encoded_sign;

			$response = wp_remote_post('https://gateway.ksher.com/api/gateway_order_query', array(
					'headers' => array('Content-Type' => 'application/x-www-form-urlencoded'),
					'body' => $data,
				)
			);

			if ($response) {
				$body = json_decode($response['body'], true);
				if ($body['code'] == 0) {
					if ( ksher_verify_sign( $body['data'], $body['sign']) ) {
						if ($status == 'pending' || $status == 'on-hold') {
							$order->add_order_note( 'Your order is paid! by ksher (by id:' . $body['data']['ksher_order_no']. ') with '. $body['data']['channel'] .' Thank you!', false );
							$order->payment_complete();
							wc_reduce_stock_levels( $_GET['mch_order_no'] );
							$woocommerce->cart->empty_cart();
							//echo esc_html('Order is paid.', 'ksher');
						} else if ($status == 'processing' || $status == 'completed') {
							//echo esc_html('Order is already paid.', 'ksher');
						} else if ($status == 'refunded') {
							//echo esc_html('Order is refunded.', 'ksher');
						}
					} else {
						//echo esc_html('Error Verify', 'ksher') . $body['code'];
					}
				} else {
					//echo esc_html('Error Code', 'ksher') . $body['code'];
				}
			} else {
				//echo esc_html('No paid.', 'ksher');
			}

		}
	}

?>