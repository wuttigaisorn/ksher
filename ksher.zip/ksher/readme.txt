=== Ksher ===
Tags: payments,woocommerce
Requires at least: 1.0.0
Tested up to: 5.5.1
Requires PHP: 7.0
WooCommerce up to: 4.5
Stable tag: 5.5.1
License: ksher

Ksher pluging is payments gateway connect with woocommerce.

== Description ==
Ksher WooCommerce Plugin is developed to integrate Ksher Payment Gateway to WooCommerce.
The plugin adds Ksher Payment Gateway payment method to WooCommerce checkout.
It is easy to set up - you can have it ready to accept payment with just a few steps.